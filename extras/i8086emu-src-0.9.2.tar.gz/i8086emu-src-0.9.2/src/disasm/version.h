#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      0
#define NASM_MINOR_VER      98
#define NASM_SUBMINOR_VER   38
#define NASM_PATCHLEVEL_VER 0
#define NASM_VERSION_ID     0x00622600
#define NASM_VER            "0.98.38"
#endif /* NASM_VERSION_H */
